<?php

namespace App\Controller;

use App\Repository\IntervenantRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Association;
use App\Controller\AssociationRepository;
use App\Entity\Structure;
use App\Entity\Adherent_Association;
use App\Entity\Adherent;
use App\Entity\Groupe;
use App\Entity\Personne;
use App\Entity\Intervenant;
use App\Repository\AdherentRepository;
use App\Repository\GroupeRepository;
use App\Repository\PersonneRepository;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class IntervenantController extends AbstractController
{

    /**
     * Pour les prochaines fonctions nous utilisons les repository via les repository du SQL classique
     */


    /*******************************************************************************************************************
     * Fonctions pour le rôle INTERVENANT
     *******************************************************************************************************************/

    /**
     * Permet d'afficher le profil de l'intervenant connecté
     * @Route("/profilintervenant", name="profilintervenant")
     * */
    public function profilintervenant(){
        $id_pers = $this->getUser()->getId();
        $repo_pers = $this->getDoctrine()->getRepository(Personne::class)-> F_profilpersonne($id_pers);
        $repo_inter = $this->getDoctrine()->getRepository(Intervenant::class)-> F_profilinternvenant($id_pers);

        return $this->render('accueil/intervenant/profilintervenant.html.twig', [
            'controller_name' => 'AcceuilController',
            'personnes' => $repo_pers,
            'intervenants' => $repo_inter
        ]);
    }

    /**
     * Permet de mettre à jour les données de l'intervenant connecté
     * @Route("/modifprofilInter/{id}", name="modifprofilIntervenant")
     * */
    public function modifprofilInter(Request $request, EntityManagerInterface $em, IntervenantRepository $repo, $id){

        $intervenant = $this->getUser()->getIdIntervenant();
        $form = $this->createFormBuilder($intervenant)
            ->add('adresse_inter',TextType::class,['label'  => "Adresse",])
            ->add('tel_inter',TextType::class,['label'  => "Téléphone",])
            ->add('save',SubmitType::class, ['label' => 'Enregistrer'])
            ->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $em->merge($intervenant);
            $em->flush();
            return $this->redirectToRoute('profilintervenant');
        }
        return $this->render('accueil/intervenant/modifprofilInter.html.twig', ['formModifProfil' => $form->createView()]);
    }

    /**
     * Permet de mettre à jour les données du profil personne d'un intervenant
     * @Route("/modifinfopers/{id}", name="modifinfopers")
     * */
    public function modifinfopers(Request $request, EntityManagerInterface $em, PersonneRepository $repo, $id){

        $personne = $repo->find($id);  /*Trouve l'id de la personne qui est connecté*/
        $form = $this->createFormBuilder($personne)  /*Utilise la fonction createFormBuilder*/
        ->add('mail_pers',TextType::class,['label'  => "Adresse mail",]) /*Enregistre la variable Adresse mail du label dans la adresse_adh BDD*/
        ->add('mdp',TextType::class,['label'  => "Mot de passe",])
            ->add('save',SubmitType::class, ['label' => 'Enregistrer'])
            ->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){ /*Si le formulaire est remplit et que l'utilisateur clic sur Enregistrer*/
            $em->merge($personne);
            $em->flush(); /*Alors les informations mis à jour dans la BDD*/
            return $this->redirectToRoute('profilintervenant'); /*Et on redirige vers le templates d'affichage du profil*/
        }
        return $this->render('accueil/intervenant/modifprofilPers.html.twig', ['formModifProfil' => $form->createView()]); /*Si les conditions ne sont pas validées alors on reste sur la page de modification du profil*/
    }

    /**
     * Permet d'afficher les associations liées à l'intevenant connecté
     * @Route("/assointervenant", name="associationintervenant")
     * */
    public function associationintervenant(){
        $id_pers = $this->getUser()->getId();
        $repo_inter = $this->getDoctrine()->getRepository(Intervenant::class)-> F_IntervenantPers($id_pers);
        $repo_asso = $this->getDoctrine()->getRepository(Association::class)-> F_associationInter($repo_inter);

        return $this->render('accueil/intervenant/assointervenant.html.twig', [
            'controller_name' => 'AcceuilController',
            'associations' => $repo_asso,
        ]);
    }

    /**
     * Permet d'afficher les groupes liées à l'intevenant connecté
     * @Route("/groupeintervenant", name="groupeintervenant")
     * */
    public function groupeintervenant(){

        $groupes= $this -> getUser()-> getIdIntervenant()->getGroupes();

        return $this->render('accueil/intervenant/groupeintervenant.html.twig', [
            'controller_name' => 'AcceuilController',
            'groupes' => $groupes,
        ]);
    }

}


?>