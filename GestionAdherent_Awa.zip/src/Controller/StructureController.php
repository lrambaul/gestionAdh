<?php

namespace App\Controller;

use App\Repository\IntervenantRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Association;
use App\Controller\AssociationRepository;
use App\Entity\Structure;
use App\Entity\Adherent_Association;
use App\Entity\Adherent;
use App\Entity\Groupe;
use App\Entity\Personne;
use App\Entity\Intervenant;
use App\Repository\AdherentRepository;
use App\Repository\GroupeRepository;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class StructureController extends AbstractController
{

    /**
     * Pour les prochaines fonctions nous utilisons les repository via les repository du SQL classique
     */

    /*******************************************************************************************************************
     * Fonctions pour le rôle STRUCTURE
     *******************************************************************************************************************/

    /**
     * Permet d'afficher les informations de la structure dont la personne connecté est responsable et de la personne qui est connecté
     * @Route("/profilstructure", name="profilstructure")
     * */
    public function profilstructure(){
        $id_pers = $this->getUser()->getId();
        $repo_pers = $this->getDoctrine()->getRepository(Personne::class)-> F_profilpersonne($id_pers);
        $repo_struc = $this->getDoctrine()->getRepository(Structure::class)-> F_profilstructure($id_pers);

        return $this->render('accueil/structure/profilstructure.html.twig', [
            'controller_name' => 'AcceuilController',
            'structures' => $repo_struc,
            'personnes' => $repo_pers,
        ]);
    }

    /**
     * Permet d'afficher toutes les associations lié à la structure dont la personne qui est connecté est responsable
     * @Route("/assostructure", name="associationstructure")
     * */
    public function associationstructure(){
        $id_pers = $this->getUser()->getId();
        $repo_struct = $this->getDoctrine()->getRepository(Structure::class)-> F_profilstructure($id_pers);
        $repo_asso = $this->getDoctrine()->getRepository(Association::class)-> F_associationStruct($repo_struct);

        return $this->render('accueil/structure/assostructure.html.twig', [
            'controller_name' => 'AcceuilController',
            'associations' => $repo_asso,
        ]);
    }

    /**
     * Permet de mettre à jour les données du profil d'une structure
     * @Route("/modifprofilStruct/{id}", name="modifprofilStructure")
     * */
    public function modifprofilStruct(Request $request, EntityManagerInterface $em, $id){

        $structure = $this->getDoctrine()->getRepository(Structure::class)->find($id);

        $form = $this->createFormBuilder($structure)
            ->add('nom_structure', TextType::class, ['label' => "Nom",])
            ->add('save', SubmitType::class, ['label' => 'Enregistrer'])
            ->getForm();
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();
            return $this->redirectToRoute('profilstructure');
        }
        return $this->render('accueil/structure/modifprofilStruct.html.twig', ['formModifProfil' => $form->createView()]);
    }

    /**
     * Permet de mettre à jour les données d'un responsable de structure
     * @Route("/modifprofilPersStruct/{id}", name="modifprofilPersStructure")
     * */
    public function modifprofilPersStruct(Request $request, EntityManagerInterface $em, $id){

        $personne = $this->getDoctrine()->getRepository(Personne::class)->find($id);
        $form = $this->createFormBuilder($personne)
            ->add('nom_pers',TextType::class,['label'  => "Nom",])
            ->add('prenom_pers',TextType::class,['label'  => "Prénom",])
            ->add('mail_pers',TextType::class,['label'  => "Adresse e-mail",])
            ->add('mdp',TextType::class,['label'  => "Mot de passe",])
            ->add('save',SubmitType::class, ['label' => 'Enregistrer'])
            ->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $em->flush();
            return $this->redirectToRoute('profilstructure');
        }
        return $this->render('accueil/structure/modifprofilStruct.html.twig', ['formModifProfil' => $form->createView()]);
    }

}


?>