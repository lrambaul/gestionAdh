<?php

namespace App\Controller;

use App\Entity\Adherent;
use App\Entity\AdminAsso;
use App\Entity\AdminStructure;
use App\Entity\Intervenant;
use App\Entity\SuperAdmin;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use App\Entity\Personne;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class SecurityController extends AbstractController
{
    /**
     * @Route("/connexion", name="security_login")
     */
    public function login(AuthenticationUtils $authenticationUtils ,Request $request)
    {
        // retrouver une erreur d'authentification s'il y en a une
        $error = $authenticationUtils->getLastAuthenticationError();
        // retrouver le dernier identifiant de connexion utilisé
        $lastUsername = $authenticationUtils->getLastUsername();

        $mail=$request->request->get('_username');
        $mdp=$request->request->get('_password');
        $personne = $this->getDoctrine()->getRepository(Personne::class)
            ->findOneBy(['mail_pers'=>$mail, 'mdp'=> $mdp]);
        $data=[];
        if ($personne !=null){
            $superAdmin=$this->getDoctrine()->getRepository(SuperAdmin::class)
                ->findOneBy(['personne'=>$personne]);
            if ($superAdmin!=null){
                array_push($data, $superAdmin);
            }
            $adminStructure=$this->getDoctrine()->getRepository(AdminStructure::class)
                ->findOneBy(['personne'=>$personne]);
            if ($adminStructure!=null){
                array_push($data, $adminStructure );
            }
            $adminAsso=$this->getDoctrine()->getRepository(AdminAsso::class)
                ->findOneBy(['personne'=>$personne]);
            if ($adminAsso!=null){
                array_push($data, $adminAsso );
            }
            $intervenant=$this->getDoctrine()->getRepository(Intervenant::class)
                ->findOneBy(['id_pers'=>$personne]);
            if ($intervenant!=null){
                array_push($data, $intervenant);
            }
            $adherent=$this->getDoctrine()->getRepository(Adherent::class)
                ->findOneBy(['personne'=>$personne]);
            if ($adherent!=null){
                array_push($data, $adherent);
            }
            dump($data);

        }

        return $this->render('security/login.html.twig', [
                'last_username' => $lastUsername,
                'error' => $error,
                'data' => $data
            ]
        );
    }

    /**
     * @Route("/deconnexion", name="security_logout")
     */
    public function logout(): void
    {
    }

}