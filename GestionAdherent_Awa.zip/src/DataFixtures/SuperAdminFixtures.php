<?php

namespace App\DataFixtures;

use App\Entity\Personne;
use App\Entity\SuperAdmin;
use App\Entity\Adherent;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use App\Repository\PersonneRepository;

class SuperAdminFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $personne = new Personne();
        $personne->setNomPers("Payen")
            ->setPrenomPers("Natacha")
            ->setMailPers("natacha-98@hotmail.fr")
            ->setMdp('nat');
        $manager->persist($personne);
        $admin = new SuperAdmin();
        $admin->setPersonne($personne);
        $adh = new Adherent();
        $adh -> setAnnivAdh(1998-9-21)
            ->setNumLicence(456789)
            -> setTel();
        $manager->persist($admin);
        $manager->flush();
    }
}
