<?php

namespace App\Controller;

use App\Repository\IntervenantRepository;
use Doctrine\DBAL\Types\DateTimeType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\BirthdayType;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Association;
use App\Controller\AssociationRepository;
use App\Entity\Structure;
use App\Entity\Adherent_Association;
use App\Entity\Adherent;
use App\Entity\Groupe;
use App\Entity\Personne;
use App\Controller\PersonneRepository;
use App\Entity\Intervenant;
use App\Repository\AdherentRepository;
use App\Repository\GroupeRepository;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class AssociationController extends AbstractController
{
    /**
     * Pour les prochaines fonctions nous utilisons les repository via les repository du SQL classique
     */


    /*******************************************************************************************************************
     * Fonctions pour le rôle ASSOCIATION
     *******************************************************************************************************************/

    /**
     * Permet d'afficher le profil de l'association dont la personne connecté est responsable et de la personne qui est connecté
     * @Route("/profilassociation", name="profilassociation")
     * */
    public function profilassociation(){
        $id_pers = $this->getUser()->getId();
        $repo_pers = $this->getDoctrine()->getRepository(Personne::class)-> F_profilpersonne($id_pers);
        $repo_asso = $this->getDoctrine()->getRepository(Association::class)-> F_profilassociation($id_pers);

        return $this->render('accueil/association/profilassociation.html.twig', [
            'controller_name' => 'AcceuilController',
            'associations' => $repo_asso,
            'personnes' => $repo_pers,
        ]);
    }

    /**
     * Permet de mettre à jour les données de l'association dont la personne connecté est responsable
     * @Route("/modifprofilAsso/{id}", name="modifprofilAssociation")
     * */
    public function modifprofilAsso(Request $request, EntityManagerInterface $em, $id){

        $association = $this->getDoctrine()->getRepository(Association::class)->find($id);

            $form = $this->createFormBuilder($association)
                ->add('adresse_asso', TextType::class, ['label' => "Adresse",])
                ->add('mail_asso', TextType::class, ['label' => "Adresse e-mail",])
                ->add('tel_asso', TextType::class, ['label' => "Téléphone",])
                ->add('save', SubmitType::class, ['label' => 'Enregistrer'])
                ->getForm();
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $em->flush();
                return $this->redirectToRoute('profilassociation');
            }
        return $this->render('accueil/association/modifprofilAsso.html.twig', ['formModifProfil' => $form->createView()]);
    }


    /**
     * Permet de mettre à jour les données du profil d'un responsable d'association
     * @Route("/modifprofilPersAsso/{id}", name="modifprofilPersAssociation")
     * */
    public function modifprofilPersAsso(Request $request, EntityManagerInterface $em, $id){

        $personne = $this->getDoctrine()->getRepository(Personne::class)->find($id);
        $form = $this->createFormBuilder($personne)
            ->add('nom_pers',TextType::class,['label'  => "Nom",])
            ->add('prenom_pers',TextType::class,['label'  => "Prénom",])
            ->add('mail_pers',TextType::class,['label'  => "Adresse e-mail",])
            ->add('mdp',TextType::class,['label'  => "Mot de passe",])
            ->add('save',SubmitType::class, ['label' => 'Enregistrer'])
            ->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $em->flush();
            return $this->redirectToRoute('profilassociation');
        }
        return $this->render('accueil/association/modifprofilAsso.html.twig', ['formModifProfil' => $form->createView()]);
    }

    /**
     * Permet d'afficher la liste des adhérents de l'association dont la personne connecté est responsable
     * @Route("/listeAdh", name="ListeAdh")
     * */
    public function ListeAdhAsso(){

        $ListeAsso= $this -> getUser()-> getAssociations();

        return $this->render('accueil/association/listeAdh.html.twig', [
            'controller_name' => 'AcceuilController',
            'associations' => $ListeAsso,
        ]);
    }

    /**
     * Permet pour le gérant de l'asso de mettre à jour les données du profil d'un adhérent
     * @Route("/modifprofilAdhpourAsso/{id}", name="modifprofilAdherentpourAsso")
     * */
    public function modifprofilAdhpourAsso(Request $request, EntityManagerInterface $em, $id){

        $personne = $this->getDoctrine()->getRepository(Personne::class)->find($id);
        $form = $this->createFormBuilder($personne)
            ->add('nom_pers',TextType::class,['label'  => "Nom",])
            ->add('prenom_pers',TextType::class,['label'  => "Prénom",])
            ->add('mail_pers',TextType::class,['label'  => "Adresse e-mail",])
            ->add('save',SubmitType::class, ['label' => 'Enregistrer'])
            ->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $em->flush();
            return $this->redirectToRoute('ListeAdh');
        }
        return $this->render('accueil/association/modifprofilAdhpourAsso.html.twig', ['formModifProfil' => $form->createView()]);
    }

    /**
    * @Route("/SupprAdh/{id}", name="supprAdh")
    * */
    public function suppr(Request $request,EntityManagerInterface $em, $id){

        $entityManager = $this->getDoctrine()->getManager();
        $adherent = $entityManager-> getRepository(Adherent::class)->find($id);
        $entityManager->remove($adherent);
        $entityManager->flush();
        return $this->redirectToRoute('supprAdhOK');
    }

    /**
     * @Route("/supprAdhOK", name="supprAdhOK")
     */
    public function supprOK(){
        return $this->render('accueil/association/SuppAdhOK.html.twig', [
        ]);
    }

    /**
     * Permet d'afficher la liste des personne existante (ajout d'un adhérent)
     * @Route("/ListePersonne/{idAsso}", name="ListePersonne")
     * */
    public function ListePersonne($idAsso){

        $repo_pers = $this->getDoctrine()->getRepository(Personne::class)-> FindAll();

            return $this->render('accueil/association/listePersonne.html.twig', [
                'personnes' => $repo_pers,
                'idAsso' => $idAsso,
            ]);
    }


    /**
     * Permet pour le gérant de l'asso d'ajouter une personne
     * @Route("/AjoutPersonne", name="AjoutPersonne")
     * */
    public function AjoutPersonne(Request $request,EntityManagerInterface $em){
        //Création d'un objet personne pour pouvoir enregistrer ses données
        $personne=new Personne;

        $form = $this->createFormBuilder($personne)
            ->add('nom_pers',TextType::class,['label'  => "Nom",])
            ->add('prenom_pers',TextType::class,['label'  => "Prénom",])
            ->add('mail_pers',TextType::class,['label'  => "Adresse e-mail",])
            ->add('mdp',TextType::class,['label'  => "Mot de passe",])
            ->add('save',SubmitType::class, ['label' => 'Enregistrer'])
            ->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $em->persist($personne);
            $em->flush();
            return $this->redirectToRoute('ListePersonne');
        }

        dump($personne);
        return $this->render('accueil/association/ajoutpersonne.html.twig', ['form' => $form->createView()]);

    }

    /**
     * Permet pour le gérant de l'asso d'ajouter un adhérent
     * @Route("/AjoutAdh/{id}/{idAsso}", name="AjoutAdh")
     * */
    public function AjoutAdh(Request $request,EntityManagerInterface $em, $id, $idAsso){
        // A FAIRE !! Il faut vérifier que l'adhérent lié à la personne n'existe pas déjà !!!

        //Récupération des entité "personne" et "association" avec leur id
        $personne = $this->getDoctrine()->getRepository(Personne::class)->find($id);
        $asso = $this->getDoctrine()->getRepository(Association::class)->find($idAsso);

        //On vérifie que l'adhérent pour cette personne n'existe pas déjà
        $idadherentexist = $personne->getAdherent()->getid();

        if($idadherentexist==null) {

            //Création d'un objet personne pour pouvoir enregistrer ses données
            $adherent = new Adherent();

            //Création du form pour enregistrer un adhérent
            $form = $this->createFormBuilder($adherent)
                ->add('anniv_adh', BirthdayType::class, ['label' => "Date d'anniversaire",])
                ->add('num_licence', TextType::class, ['label' => "Numéro de licence",])
                ->add('tel', TextType::class, ['label' => "Téléphonne",])
                ->add('adresse_adh', TextType::class, ['label' => "Adresse",])
                ->add('save', SubmitType::class, ['label' => 'Enregistrer'])
                ->getForm();
            $form->handleRequest($request);

            // Seulement si le form est valide
            if ($form->isSubmitted() && $form->isValid()) {
                //On lie l'adhérent à la personne
                $adherent->setPersonne($personne);
                //On lie l'adhérent à l'association
                $adherent->addAsso($asso);

                // On persist et on flush avec la base de donnée
                $em->persist($adherent);
                $em->flush();

                //On lie la personne à l'adhérent nouvellement créé
                $personne->setAdherent($adherent);
                return $this->render('accueil/association/ajoutAdhOK.html.twig');
            }

            //Si le form n'est pas valide on supprime l'adhérent
            dump($adherent);
            //Et on retoure à la page 'listeAdh'
            return $this->render('accueil/association/ajoutpersonne.html.twig', ['form' => $form->createView()]);

        }

        elseif($idadherentexist!=null){
            $id=intval($idadherentexist);
            $adherentexist = $this->getDoctrine()->getRepository(Adherent::class)->find($id);
            $adherentexist->addAsso($asso);
            $em->persist($adherentexist);
            $em->flush();
            return $this->render('accueil/association/ajoutAdhOK.html.twig');
        }

        else{
            return $this->redirectToRoute('home');
        }
    }
    /**
     * Permet de créer un adhérent
     * @Route("/addadh", name="addadh")
     * */
    /*public function create(Request $requestAdh,ObjectManager $manager){
        $adherent = new Adherent;
        $formAdh = $this->createFormBuilder($adherent)
            ->add ('num_licence',TextType::class,['label'  => "Numéro de Licence",])
            ->add('name',TextType::class,['label'  => "Nom",])
            ->add('first_name',TextType::class,['label'  => "Prénom",])
            ->add('mail',TextType::class,['label'  => "Adresse e-mail",])
            ->add('birthday',DateType::class, ['widget' => 'single_text','label'  => "Date d'anniversaire",])
            ->add('address',TextType::class,['label'  => "Adresse postale",])
            ->add('tel',TextType::class,['label'  => "Téléphone",])
            ->add('gender', TextType::class, ['label'  => "Genre",])
            ->add('nationality',TextType::class,['label'  => "Nationalité",])
            ->add('save',SubmitType::class, ['label' => 'Enregistrer'])
            ->getForm();

        $formAdh->handleRequest($requestAdh);
        if($formAdh->isSubmitted() && $formAdh->isValid()){
            $manager->persist($adherent);
            $manager->flush();
            return $this->redirectToRoute('addlogin');
        }
        dump($adherent);
        return $this->render('acceuil/addadh.html.twig', ['formAdherent' => $formAdh->createView()]);
    }*/

    /**
     * Permet d'afficher la liste des groupes et des adhérents faisant parti de ses groupes pour l'association dont la personne connecté est responsable
     * @Route("/listeGroupe", name="ListeGroupe")
     * */
    public function ListeGroupeAsso(){

        $ListeGroupe= $this -> getUser()-> getAssociations();

        return $this->render('accueil/association/listeAdh.html.twig', [
            'controller_name' => 'AcceuilController',
            'associations' => $ListeAsso,
        ]);
    }
























}


?>