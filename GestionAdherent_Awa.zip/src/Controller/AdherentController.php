<?php

namespace App\Controller;

use App\Repository\IntervenantRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Association;
use App\Controller\AssociationRepository;
use App\Entity\Structure;
use App\Entity\Adherent_Association;
use App\Entity\Adherent;
use App\Entity\Groupe;
use App\Entity\Personne;
use App\Entity\Intervenant;
use App\Repository\AdherentRepository;
use App\Repository\PersonneRepository;
use App\Repository\GroupeRepository;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class AdherentController extends AbstractController
{

    /**
     * Pour les prochaines fonctions nous utilisons les repository via les repository du SQL classique
     */

    /*******************************************************************************************************************
     * Fonctions pour le rôle ADHERENT
     *******************************************************************************************************************/

    /**
     * Permet d'afficher le profil de l'adherent qui est connecté
     * @Route("/profilpersonne", name="profilpersonne")
     * */

    public function profilpersonne(){
        $id_pers = $this->getUser()->getId(); /*Va chercher l'id de la personne qui est connecté*/
        $repo_pers = $this->getDoctrine()->getRepository(Personne::class)-> F_profilpersonne($id_pers); /*Va chercher toutes les informations de la personne qui est connecté*/
        $repo_adh = $this->getDoctrine()->getRepository(Adherent::class)-> F_profiladherent($id_pers); /*Va chercher toutes les informations de l'adherent qui est connecté*/

        return $this->render('accueil/adherent/profilpersonne.html.twig', [ /*Envoie les informations vers le templates d'affichage*/
            /*'controller_name' => 'AcceuilController',*/
            'personnes' => $repo_pers,  /*Envoie les informations récupérées par la fonction associée vars la variable utilisé dans le templates*/
            'adherents' => $repo_adh /*Envoie les informations récupérées par la fonction associée vars la variable utilisé dans le templates*/
        ]);
    }

    /**
     * Permet d'afficher la liste des associations liées à l'adhérent connecté
     * @Route("/assoadherent", name="associationadherent")
     * */
    public function associationadherent(){
        $id_pers = $this->getUser()->getId(); /*Va chercher l'id de la personne qui est connecté*/
        $repo_adh = $this->getDoctrine()->getRepository(Adherent::class)-> F_IDadherentpers($id_pers); /*Va chercher l'id adhérent de la personne qui est connecté*/
        $repo_asso = $this->getDoctrine()->getRepository(Association::class)-> F_associationAdh($repo_adh); /*Va chercher toutes les informations des associations liées à la personne qui est connecté*/

        return $this->render('accueil/adherent/assoadherent.html.twig', [ /*Envoie les informations vers le templates d'affichage*/
            /*'controller_name' => 'AcceuilController',*/
            'associations' => $repo_asso, /*Envoie les informations récupérées par la fonction associée vars la variable utilisé dans le templates*/
        ]);
    }

    /**
     * Permet de mettre à jour les données du profil d'un adhérent
     * @Route("/modifprofilAdh/{id}", name="modifprofilAdherent")
     * */
    public function modifprofilAdh(Request $request, EntityManagerInterface $em, AdherentRepository $repo, $id){

        $adherent = $repo->find($id);  /*Trouve l'id de la personne qui est connecté*/
        $form = $this->createFormBuilder($adherent)  /*Utilise la fonction createFormBuilder*/
            ->add('adresse_adh',TextType::class,['label'  => "Adresse",]) /*Enregistre la variable Adresse du label dans la adresse_adh BDD*/
            ->add('tel',TextType::class,['label'  => "Téléphone",])
            ->add('save',SubmitType::class, ['label' => 'Enregistrer'])
            ->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){ /*Si le formulaire est remplit et que l'utilisateur clic sur Enregistrer*/
            $em->merge($adherent);
            $em->flush(); /*Alors les informations mis à jour dans la BDD*/
            return $this->redirectToRoute('profilpersonne'); /*Et on redirige vers le templates d'affichage du profil*/
        }
        return $this->render('accueil/adherent/modifprofilAdh.html.twig', ['formModifProfil' => $form->createView()]); /*Si les conditions ne sont pas validées alors on reste sur la page de modification du profil*/
    }

    /**
     * Permet de mettre à jour les données du profil personne d'un adhérent (mail et mdp)
     * @Route("/modifinfopersonne/{id}", name="modifinfopersonne")
     * */
    public function modifinfopersonne(Request $request, EntityManagerInterface $em, PersonneRepository $repo, $id){

        $personne = $repo->find($id);  /*Trouve l'id de la personne qui est connecté*/
        $form = $this->createFormBuilder($personne)  /*Utilise la fonction createFormBuilder*/
        ->add('mail_pers',TextType::class,['label'  => "Adresse mail",]) /*Enregistre la variable Adresse mail du label dans la adresse_adh BDD*/
        ->add('mdp',TextType::class,['label'  => "Mot de passe",])
            ->add('save',SubmitType::class, ['label' => 'Enregistrer'])
            ->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){ /*Si le formulaire est remplit et que l'utilisateur clic sur Enregistrer*/
            $em->merge($personne);
            $em->flush(); /*Alors les informations mis à jour dans la BDD*/
            return $this->redirectToRoute('profilpersonne'); /*Et on redirige vers le templates d'affichage du profil*/
        }
        return $this->render('accueil/adherent/modifprofilPersonne.html.twig', ['formModifProfil' => $form->createView()]); /*Si les conditions ne sont pas validées alors on reste sur la page de modification du profil*/
    }

    /**
     * Permet d'afficher les groupes auxquels appartient l'adhérent connecté
     * @Route("/groupeadherent", name="groupeadherent")
     * */
    public function groupeadherent(){
       /* $Liste_Groupe = $this->getUser()->getAdherent()->getGroupe();*/
        $id_pers = $this->getUser()->getId();
        $repo_adh = $this->getDoctrine()->getRepository(Adherent::class)-> F_IDadherentpers($id_pers); /*Va chercher l'id adhérent de la personne qui est connecté*/
        $repo_grp = $this->getDoctrine()->getRepository(Groupe::class)-> F_GroupeAdh($repo_adh); /*Va chercher tout les groupes liés à la personne qui est connecté*/

        return $this->render('accueil/adherent/groupeadherent.html.twig', [
             /*'controller_name' => 'AcceuilController',*/
            'groupes' => $repo_grp, /*Envoie les informations récupérées par la fonction associée vars la variable utilisé dans le templates*/
        ]);
    }

}


?>