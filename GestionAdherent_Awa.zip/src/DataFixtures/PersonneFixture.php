<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use App\Entity\Personne;
use App\Entity\SuperAdmin;

class PersonneFixture extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $personne = new Personne();
        $personne->setNomPers("Payen")
                ->setPrenomPers("Natacha")
                ->setMailPers("natacha.payen98@gmail.com")
                ->setMdp('nat');
        $manager->persist($personne);
        $personne1 = new Personne();
        $personne1->setNomPers("Castillo")
            ->setPrenomPers("Noémie")
            ->setMailPers("castillo.noemie.stl@gmail.com")
            ->setMdp('nono');
        $manager->persist($personne1);
        $personne2 = new Personne();
        $personne2->setNomPers("Barbe")
            ->setPrenomPers("Fanny")
            ->setMailPers("fanny.barbe05@gmail.com")
            ->setMdp('fan');
        $manager->persist($personne2);
        $personne3 = new Personne();
        $personne3->setNomPers("Bouvier")
            ->setPrenomPers("Julie")
            ->setMailPers("julie.bouvier1996@gmail.com")
            ->setMdp('juju');
        $manager->persist($personne3);
        #$super = new SuperAdmin();
        #$super->setIdPers($personne->getId());
        #$manager->persist($super);
        $manager->flush();
    }
}
